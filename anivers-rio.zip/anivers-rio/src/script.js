function openNewWindow() {
  var newWindow = window.open("", "_blank");
  newWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Surpresa Romântica</title>
            <style>
                body {
                    background: url("hearts_background.jpg") no-repeat center center fixed;
                    background-size: cover;
                    font-family: Arial, sans-serif;
                    margin: 0;
                    overflow: hidden;
                }

                .fullscreen-container {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }

                .message-container {
                    text-align: center;
                }

                h2 {
                    font-size: 40px;
                    color: white;
                    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
                }
            </style>
        </head>
        <body>
            <div class="fullscreen-container">
                <div class="message-container">
                    <h2>Feliz Aniversário, Te amo ❤️</h2>
                </div>
            </div>
        </body>
        </html>
    `);
  newWindow.document.close();
}
